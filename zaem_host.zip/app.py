import os, sqlite3
from flask import Flask, render_template, request, redirect, url_for, session, flash, jsonify
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.secret_key = os.getenv("SECRET_KEY", "change-this-secret-key")
DB = os.getenv("DB_PATH", "zaem_host.db")

def db():
    con = sqlite3.connect(DB)
    con.row_factory = sqlite3.Row
    return con

def init_db():
    con = db()
    con.executescript("""
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      username TEXT UNIQUE NOT NULL,
      password TEXT NOT NULL,
      is_admin INTEGER DEFAULT 0
    );
    CREATE TABLE IF NOT EXISTS projects (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL,
      name TEXT NOT NULL,
      status TEXT DEFAULT 'stopped',
      FOREIGN KEY(user_id) REFERENCES users(id)
    );
    """)
    if not con.execute("SELECT 1 FROM users WHERE username='admin'").fetchone():
        con.execute("INSERT INTO users(username,password,is_admin) VALUES(?,?,1)",
                    ("admin", generate_password_hash("admin123")))
    con.commit()
    con.close()

@app.before_request
def setup():
    init_db()

def current_user():
    if "user_id" not in session: return None
    return db().execute("SELECT * FROM users WHERE id=?", (session["user_id"],)).fetchone()

@app.route("/")
def index():
    return render_template("index.html", user=current_user())

@app.route("/register", methods=["GET","POST"])
def register():
    if request.method == "POST":
        u, p = request.form["username"].strip(), request.form["password"]
        if not u or len(p) < 6:
            flash("اكتب اسم مستخدم وكلمة مرور 6 أحرف على الأقل.")
            return redirect(url_for("register"))
        con=db()
        try:
            cur=con.execute("INSERT INTO users(username,password) VALUES(?,?)",
                            (u, generate_password_hash(p)))
            con.commit()
            session["user_id"]=cur.lastrowid
            return redirect(url_for("dashboard"))
        except sqlite3.IntegrityError:
            flash("اسم المستخدم موجود بالفعل.")
        finally: con.close()
    return render_template("auth.html", title="إنشاء حساب", action="/register")

@app.route("/login", methods=["GET","POST"])
def login():
    if request.method=="POST":
        u=request.form["username"].strip()
        row=db().execute("SELECT * FROM users WHERE username=?", (u,)).fetchone()
        if row and check_password_hash(row["password"], request.form["password"]):
            session["user_id"]=row["id"]
            return redirect(url_for("admin" if row["is_admin"] else "dashboard"))
        flash("بيانات الدخول غير صحيحة.")
    return render_template("auth.html", title="تسجيل الدخول", action="/login")

@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("index"))

@app.route("/dashboard")
def dashboard():
    u=current_user()
    if not u: return redirect(url_for("login"))
    projects=db().execute("SELECT * FROM projects WHERE user_id=?", (u["id"],)).fetchall()
    return render_template("dashboard.html", user=u, projects=projects)

@app.route("/project/new", methods=["POST"])
def new_project():
    u=current_user()
    if not u: return redirect(url_for("login"))
    name=request.form["name"].strip()
    if name:
        con=db(); con.execute("INSERT INTO projects(user_id,name) VALUES(?,?)",(u["id"],name)); con.commit(); con.close()
    return redirect(url_for("dashboard"))

@app.route("/project/<int:pid>/toggle", methods=["POST"])
def toggle(pid):
    u=current_user()
    if not u: return jsonify(error="unauthorized"),401
    con=db()
    row=con.execute("SELECT * FROM projects WHERE id=? AND user_id=?",(pid,u["id"])).fetchone()
    if not row: return jsonify(error="not found"),404
    new="running" if row["status"]!="running" else "stopped"
    con.execute("UPDATE projects SET status=? WHERE id=?",(new,pid)); con.commit(); con.close()
    return redirect(url_for("dashboard"))

@app.route("/admin")
def admin():
    u=current_user()
    if not u or not u["is_admin"]: return redirect(url_for("login"))
    con=db()
    users=con.execute("SELECT id,username,is_admin FROM users ORDER BY id DESC").fetchall()
    projects=con.execute("""SELECT p.*,u.username FROM projects p JOIN users u ON u.id=p.user_id
                            ORDER BY p.id DESC""").fetchall()
    con.close()
    return render_template("admin.html", user=u, users=users, projects=projects)

if __name__=="__main__":
    app.run(host="0.0.0.0", port=int(os.getenv("PORT","5000")))
