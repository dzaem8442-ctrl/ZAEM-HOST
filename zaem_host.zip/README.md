# ZAEM HOST - نسخة أولية
هذه نسخة أولية لواجهة منصة استضافة مع تسجيل/دخول ولوحة مستخدم ولوحة Admin.
تشغيل المشاريع فعلياً داخل حاويات Docker وربطها بالسيرفر يحتاج طبقة Worker/API إضافية.

## تشغيل محلي
pip install -r requirements.txt
python app.py

افتح http://127.0.0.1:5000

حساب الإدارة الافتراضي:
username: admin
password: admin123

غيّر كلمة المرور وSECRET_KEY قبل النشر.

## Docker
docker build -t zaem-host .
docker run -p 5000:5000 -e SECRET_KEY='ضع-مفتاح-قوي' zaem-host
